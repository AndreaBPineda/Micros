/*
 * File:   main.c
 * Author: Andrea Barrientos Pineda, 20575
 *
 * Created on 4 de abril de 2022, 12:16 PM
 * 
 * Laboratorio 07: Programaci�n en C
 * Prelab: Contador con botones
 */

// Config 1
#pragma config FOSC = INTRC_NOCLKOUT
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config MCLRE = OFF
#pragma config CP = OFF
#pragma config CPD = OFF
#pragma config BOREN = OFF
#pragma config IESO = OFF
#pragma config FCMEN = OFF
#pragma config LVP = OFF

// Config 2
#pragma config BOR4V = BOR40V
#pragma config WRT = OFF

// Libraries
#include <xc.h>
#include <stdint.h>

// Constants
#define PB0 PORTBbits.RB0   // Pushbutton 1: Increase counter
#define PB1 PORTBbits.RB1   // Pushbutton 2: Decrease counter

// Variables
int counter = 0;

// Declaracion de funciones
void setup(void);

void __interrupt() isr (void)
{
    if (INTCONbits.RBIF)
    {
        if (!PB0)
            PORTA++;
   
        else if (!PB1)
            PORTA--;
        
        INTCONbits.RBIF = 0;
    }
    
    return;
}

// Main program
void main(void)
{
    setup();                            // Call PIC config
    
    // Main loop
    while (1)
    {
        
    }
    
    return;
}

void setup(void)
{
    // Config digital I/O
    ANSEL = 0;
    ANSELH = 0;
    
    // Config oscilator
    OSCCONbits.IRCF = 0b0110;   // 4MHz
    OSCCONbits.SCS = 1;         // Internal oscilator
    
    // Inputs
    TRISBbits.TRISB0 = 1;       // Input in bit 0 of PORTB
    TRISBbits.TRISB1 = 1;       // Input in bit 1 of PORTB
    
    // Outputs
    TRISA = 0;                  // PORTA as output
    
    // Config ports
    OPTION_REGbits.nRBPU = 0;   // Habilitar resistencias pull-up en PORTB
    WPUBbits.WPUB0 = 1;         // Habilitar resistencia pull-up de RB0
    WPUBbits.WPUB1 = 1;         // Habilitar resistencia pull-up de RB1
    
    // Config interruptions
    INTCONbits.GIE = 1;         // Habilitar interrupciones globales
    INTCONbits.RBIE = 1;        // Habilitar interrupciones de PORTB
    IOCBbits.IOCB0 = 1;         // Habilitar interrupci�n on-change en RB0
    IOCBbits.IOCB1 = 1;         // Habilitar interrupci�n on-change en RB1
    INTCONbits.RBIF = 0;        // Limpiar bandera de interrupci�n
    
    // Clean ports
    PORTA = 0;                  // Clean PORTA
    PORTB = 0;                  // Clean PORTB
    
    return;
}


